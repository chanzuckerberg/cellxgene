# import the built in auth types so they can be registered

import backend.server.auth.auth_none  # noqa: F401
import backend.server.auth.auth_test  # noqa: F401
import backend.server.auth.auth_session  # noqa: F401
