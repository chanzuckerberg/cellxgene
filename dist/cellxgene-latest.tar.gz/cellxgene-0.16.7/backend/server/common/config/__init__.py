from backend.common.utils.aws_secret_utils import get_secret_key  # noqa F504

DEFAULT_SERVER_PORT = 5005
BIG_FILE_SIZE_THRESHOLD = 100 * 2 ** 20  # 100MB
